
package com.pivotech.utils.extentreports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * ExtentTestManager manages ExtentTest instances with unique case IDs.
 */
public class ExtentTestManager {

    private static final Map<String, ExtentTest> extentTestMap = new HashMap<>();
    private static ExtentReports extentReports;
    private static String testCaseId;

    /**
     * Initializes the ExtentReports instance with a given class name.
     *
     * @param className The name of the test class for the report.
     */
    public static synchronized void initializeExtentReports(String className) {
        extentReports = ExtentManager.createExtentReports(className);
    }

    /**
     * Retrieves the current ExtentTest instance associated with the active test case.
     *
     * @return The ExtentTest instance for the current case ID.
     */
    public static synchronized ExtentTest getTest() {
        return extentTestMap.get(testCaseId);
    }

    /**
     * Starts a new test and associates it with a unique case ID.
     *
     * @param testName Name of the test.
     * @param desc     Description of the test.
     * @param caseId   Unique identifier for the test case.
     * @return A new ExtentTest instance.
     */
    public static synchronized ExtentTest startTest(String testName, String desc, String caseId) {
        ExtentTest test = extentReports.createTest(testName, desc);
        testCaseId = caseId;
        test.info("Case ID: " + caseId);
        extentTestMap.put(caseId, test);
        return test;
    }

    /**
     * Captures a screenshot and embeds it in the Extent report.
     *
     * @param driver WebDriver instance for capturing the screenshot.
     * @param test   ExtentTest instance where the screenshot will be embedded.
     */
    public static synchronized void captureScreenshot(WebDriver driver, ExtentTest test) {
        try {
            // Capture screenshot as Base64
            String base64Screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);

            // Embed the screenshot in the Extent report
            String screenshotHTML = "<img src='data:image/png;base64," + base64Screenshot +
                    "' style='width: 100%; max-height: 500px;' />";
            test.info("Screenshot: " + screenshotHTML);
        } catch (Exception e) {
            test.warning("Failed to capture screenshot: " + e.getMessage());
        }
    }
}
