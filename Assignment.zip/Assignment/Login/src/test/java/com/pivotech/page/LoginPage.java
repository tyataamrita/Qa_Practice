package com.pivotech.page;

import com.pivotech.helper.PageObject;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static org.junit.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage extends PageObject {
    private static final Logger logger = LogManager.getLogger(LoginPage.class);

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    // Locators
    By UserName = By.id("user-name");
    By Password = By.id("password");    
    By Loginbutton = By.xpath("//input[@id='login-button']");
    By Message = By.cssSelector("h3[data-test='error']");
    By SuccessElement = By.xpath("//span[@class='title']");

    public LoginPage Loginwithmsg(Map<String, String> userData) throws InterruptedException {
        writeText(UserName, userData.get("username"));
        writeText(Password, userData.get("password"));
        click(Loginbutton);
        Thread.sleep(2000); // Consider using explicit waits instead
        
        if (isElementDisplayed(Message)) {
            String loginMsg = readText(Message);
            System.out.println("Error Message: " + loginMsg);
        } else if (isElementDisplayed(SuccessElement)) {
            String successMsg = readText(SuccessElement);
            System.out.println("Success Message: " + successMsg);
        } else {
            System.out.println("No message displayed.");
        }
        
        return this;
    }

    public LoginPage msgcheck(String expected_result, String caseid) {
        String actual_result = "";

        if (isElementDisplayed(Message)) {
            actual_result = readText(Message);
        } else if (isElementDisplayed(SuccessElement)) {
            actual_result = readText(SuccessElement);
        } else {
            System.out.println("No message displayed: " + caseid);
            return this;
        }
        try {
            assertEquals(expected_result, actual_result);
            //logger.info("Test Passed for Case ID: " + caseid + " | Expected: " + expected_result + " | Actual: " + actual_result);
        } catch (AssertionError e) {
           // logger.error("Test Failed for Case ID: " + caseid + " | Expected: " + expected_result + " | Actual: " + actual_result);
        }

        return this;
    }

    public String getActualResult() {
        if (isElementDisplayed(Message)) {
            return readText(Message);
        } else if (isElementDisplayed(SuccessElement)) {
            return readText(SuccessElement);
        }
        return "No message displayed";
    }

    public LoginPage refreshPage() {
        driver.navigate().refresh();
        return this;
    }


}
