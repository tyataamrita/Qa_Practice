package com.pivotech.pageTest;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import static com.pivotech.pageTest.BaseTest.driver;
import static com.pivotech.pageTest.BaseTest.openUrl;
import com.pivotech.utils.extentreports.ExtentManager;
import com.pivotech.utils.extentreports.ExtentTestManager;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 *
 * @author samyog
 */
public class LoginPageTest extends BaseTest{
    
//    private ExtentTest extentTest;
//    public static final Logger logger = LogManager.getLogger(LoginPageTest.class);
//
//    @BeforeClass
//    public void beforeClass() {
//        // Initialize the Extent Reports for the current class
//        ExtentTestManager.initializeExtentReports(this.getClass().getSimpleName());
//    }
//    @AfterClass
//    public void afterClass() {
//        ExtentManager.extentReports.flush();
//    }
     public ExtentTest extentTest;
    private static final String CLASS_NAME = LoginPageTest.class.getSimpleName();

    static {
        // Set system property for dynamic log file naming
        System.setProperty("logFilename", CLASS_NAME);
    }

    private static final Logger logger = LogManager.getLogger(LoginPageTest.class);
    
    @BeforeClass
    public void beforeClass() {
        // Initialize the Extent Reports for the current class
        ExtentTestManager.initializeExtentReports(this.getClass().getSimpleName());
    }

    @AfterClass
    public void afterClass() {
        ExtentManager.extentReports.flush();
    }
    
    @Test
    public void Logintest() throws InterruptedException, IOException  {
      openUrl("");
        
        String csvFilePath = "TestDataset/Login.csv";
        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            List<String[]> lines = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                lines.add(line.split(","));
            }
            String[] headers = lines.get(0);
            for (int i = 1; i < lines.size(); i++) {
                String[] data = lines.get(i);
                Map<String, String> userData = new HashMap<>();
                for (int j = 0; j < headers.length; j++) {
                    userData.put(headers[j], getValueAtIndex(data, j));
                }

                String expected_result = userData.get("expected");
                String testcase = userData.get("testcase");
                String caseid = userData.get("caseid");

    
            
            ExtentTest extentTest = ExtentTestManager.startTest("LoginPageTest", testcase, caseid);
                logger.info("Starting test: " + testcase + " with Case ID: " + caseid);

                loginpage.Loginwithmsg(userData).msgcheck(expected_result, caseid);
                String actual_result = loginpage.getActualResult();
                if (expected_result.equals(actual_result)) {
                    logger.info("Test Passed | Case ID: " + caseid + " | Expected: " + expected_result + " | Actual: " + actual_result);
                    extentTest.log(Status.PASS, "Test Passed | Case ID: " + caseid + " | Expected: " + expected_result + " | Actual: " + actual_result);
                } else {
                    logger.error("Test Failed | Case ID: " + caseid + " | Expected: " + expected_result + " | Actual: " + actual_result);
                    extentTest.log(Status.FAIL, "Test Failed | Case ID: " + caseid + " | Expected: " + expected_result + " | Actual: " + actual_result);
                    ExtentTestManager.captureScreenshot(driver, extentTest);  // Capture screenshot for failure
                }
   
         loginpage.refreshPage();     
            }
            
      }
}

 private String getValueAtIndex(String[] data, int index) {
        return data.length > index ? data[index] : null;
    }
}
        
        
        
        
    
