package com.pivotech.pageTest;

//import com.pivotech.page.CreateProductPage;
import com.pivotech.page.LoginPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

/**
 *
 * @author samyog
 */
public class BaseTest {
    protected static WebDriver driver;
    public LoginPage loginpage;
   
    
    public WebDriver getDriver(){
        return driver;
    }
    
    @BeforeSuite
    public void setupProxy(){
        
    }
    
    @BeforeClass
    public static void setUp(){
        ResourceBundle bundle= ResourceBundle.getBundle("bundle");
        ChromeOptions options= new ChromeOptions();
        WebDriverManager.chromedriver().setup();
        
        options.setAcceptInsecureCerts(true);
        options.addArguments("--user-data-dir=/tmp/chrome-profile-" + System.currentTimeMillis());

        
        String Headless = bundle.getString("Headless");
        if (Headless.equals("FALSE")) {
            options.addArguments("--remote-allow-origins=*");
            } else if (Headless.equals("TRUE")){
                options.addArguments("--headless=new");
                options.addArguments("--headless=new");
                options.addArguments("--no-sandbox");
                options.addArguments("--disable-dev-shm-usage");
    }
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
    }
    
    @After
    public void cleanUp(){
        driver.manage().deleteAllCookies();
        
    }
    
    @BeforeMethod
    public void methodLevelSetup() {
           loginpage = new LoginPage(driver);
           
    }
    
    @AfterClass
    public void teardown()  {
        if (driver != null) {
        driver.quit();
    }
                   

    }
    
   
    
    public static void openUrl(String url) {
        String baseName = "bundle";
        ResourceBundle exampleBundle = ResourceBundle.getBundle(baseName);
        String targetHost = exampleBundle.getString("targetHost");
        String targetPort = exampleBundle.getString("targetPort");
        String app = exampleBundle.getString("app");
        String protocal = exampleBundle.getString("protocal");
        String baseUrl = protocal + "://" + targetHost + targetPort + "/" + app;

        driver.get(baseUrl + url);
    }
}

