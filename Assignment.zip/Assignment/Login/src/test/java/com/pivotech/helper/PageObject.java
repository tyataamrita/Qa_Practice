package com.pivotech.helper;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author samyog
 */
public class PageObject {
    public WebDriver driver;
    public WebDriverWait wait;
    public FluentWait fluentWait;
    
    //Constructor
    public PageObject(WebDriver driver){
        this.driver= driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(10).getSeconds());
        fluentWait = new FluentWait(driver).withTimeout(10, TimeUnit.SECONDS)
                .pollingEvery(Duration.ofSeconds(1l)).ignoring(NoSuchElementException.class);
        
    }
    
    // Click Method
    public void click(By by){
        waitVisibility(by).click();
    }
    
     //Wait
    public WebElement waitVisibility(By by) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }
    
    //Write Text
    public void writeText(By by, String text) {
        waitVisibility(by).sendKeys(text == null || text.isEmpty() ? new StringBuilder("") : text);
    }

    //Read Text
    public String readText(By by) {
        return waitVisibility(by).getText();
    }
    public boolean isElementDisplayed(By locator) {
        try {
            return driver.findElement(locator).isDisplayed();
        } catch (Exception e) {
            return false;
}}
    
}

