/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 1156.0, "minX": 0.0, "maxY": 14274.0, "series": [{"data": [[0.0, 1156.0], [0.1, 1156.0], [0.2, 1284.0], [0.3, 1286.0], [0.4, 1292.0], [0.5, 1322.0], [0.6, 1322.0], [0.7, 1322.0], [0.8, 1388.0], [0.9, 1388.0], [1.0, 1395.0], [1.1, 1395.0], [1.2, 1437.0], [1.3, 1457.0], [1.4, 1479.0], [1.5, 1497.0], [1.6, 1497.0], [1.7, 1522.0], [1.8, 1563.0], [1.9, 1580.0], [2.0, 1596.0], [2.1, 1596.0], [2.2, 1610.0], [2.3, 1641.0], [2.4, 1657.0], [2.5, 1667.0], [2.6, 1667.0], [2.7, 1676.0], [2.8, 1694.0], [2.9, 1708.0], [3.0, 1721.0], [3.1, 1721.0], [3.2, 1751.0], [3.3, 1781.0], [3.4, 1834.0], [3.5, 1841.0], [3.6, 1841.0], [3.7, 2003.0], [3.8, 2034.0], [3.9, 2065.0], [4.0, 2126.0], [4.1, 2126.0], [4.2, 2139.0], [4.3, 2164.0], [4.4, 2174.0], [4.5, 2183.0], [4.6, 2183.0], [4.7, 2220.0], [4.8, 2262.0], [4.9, 2287.0], [5.0, 2289.0], [5.1, 2289.0], [5.2, 2301.0], [5.3, 2303.0], [5.4, 2308.0], [5.5, 2309.0], [5.6, 2309.0], [5.7, 2313.0], [5.8, 2314.0], [5.9, 2319.0], [6.0, 2346.0], [6.1, 2346.0], [6.2, 2367.0], [6.3, 2383.0], [6.4, 2435.0], [6.5, 2439.0], [6.6, 2439.0], [6.7, 2457.0], [6.8, 2460.0], [6.9, 2463.0], [7.0, 2498.0], [7.1, 2498.0], [7.2, 2509.0], [7.3, 2546.0], [7.4, 2563.0], [7.5, 2568.0], [7.6, 2568.0], [7.7, 2595.0], [7.8, 2597.0], [7.9, 2600.0], [8.0, 2603.0], [8.1, 2603.0], [8.2, 2614.0], [8.3, 2615.0], [8.4, 2636.0], [8.5, 2638.0], [8.6, 2638.0], [8.7, 2640.0], [8.8, 2644.0], [8.9, 2679.0], [9.0, 2693.0], [9.1, 2693.0], [9.2, 2696.0], [9.3, 2712.0], [9.4, 2716.0], [9.5, 2719.0], [9.6, 2719.0], [9.7, 2721.0], [9.8, 2728.0], [9.9, 2744.0], [10.0, 2745.0], [10.1, 2745.0], [10.2, 2748.0], [10.3, 2749.0], [10.4, 2756.0], [10.5, 2762.0], [10.6, 2762.0], [10.7, 2770.0], [10.8, 2793.0], [10.9, 2796.0], [11.0, 2812.0], [11.1, 2812.0], [11.2, 2817.0], [11.3, 2830.0], [11.4, 2831.0], [11.5, 2833.0], [11.6, 2833.0], [11.7, 2849.0], [11.8, 2875.0], [11.9, 2877.0], [12.0, 2905.0], [12.1, 2905.0], [12.2, 2918.0], [12.3, 2926.0], [12.4, 2946.0], [12.5, 2952.0], [12.6, 2952.0], [12.7, 2969.0], [12.8, 2990.0], [12.9, 3009.0], [13.0, 3022.0], [13.1, 3022.0], [13.2, 3028.0], [13.3, 3037.0], [13.4, 3043.0], [13.5, 3073.0], [13.6, 3073.0], [13.7, 3084.0], [13.8, 3100.0], [13.9, 3112.0], [14.0, 3113.0], [14.1, 3113.0], [14.2, 3116.0], [14.3, 3139.0], [14.4, 3143.0], [14.5, 3144.0], [14.6, 3144.0], [14.7, 3154.0], [14.8, 3162.0], [14.9, 3170.0], [15.0, 3176.0], [15.1, 3176.0], [15.2, 3180.0], [15.3, 3192.0], [15.4, 3226.0], [15.5, 3262.0], [15.6, 3262.0], [15.7, 3275.0], [15.8, 3279.0], [15.9, 3280.0], [16.0, 3286.0], [16.1, 3286.0], [16.2, 3291.0], [16.3, 3295.0], [16.4, 3333.0], [16.5, 3359.0], [16.6, 3359.0], [16.7, 3380.0], [16.8, 3397.0], [16.9, 3399.0], [17.0, 3404.0], [17.1, 3404.0], [17.2, 3425.0], [17.3, 3433.0], [17.4, 3462.0], [17.5, 3464.0], [17.6, 3464.0], [17.7, 3467.0], [17.8, 3475.0], [17.9, 3477.0], [18.0, 3481.0], [18.1, 3481.0], [18.2, 3494.0], [18.3, 3499.0], [18.4, 3521.0], [18.5, 3543.0], [18.6, 3543.0], [18.7, 3571.0], [18.8, 3574.0], [18.9, 3581.0], [19.0, 3600.0], [19.1, 3600.0], [19.2, 3605.0], [19.3, 3615.0], [19.4, 3616.0], [19.5, 3620.0], [19.6, 3620.0], [19.7, 3627.0], [19.8, 3636.0], [19.9, 3649.0], [20.0, 3659.0], [20.1, 3659.0], [20.2, 3659.0], [20.3, 3697.0], [20.4, 3722.0], [20.5, 3740.0], [20.6, 3740.0], [20.7, 3770.0], [20.8, 3771.0], [20.9, 3803.0], [21.0, 3811.0], [21.1, 3811.0], [21.2, 3811.0], [21.3, 3846.0], [21.4, 3863.0], [21.5, 3880.0], [21.6, 3880.0], [21.7, 3883.0], [21.8, 3887.0], [21.9, 3902.0], [22.0, 3919.0], [22.1, 3919.0], [22.2, 3935.0], [22.3, 3963.0], [22.4, 3971.0], [22.5, 3971.0], [22.6, 3971.0], [22.7, 3975.0], [22.8, 4030.0], [22.9, 4036.0], [23.0, 4050.0], [23.1, 4050.0], [23.2, 4054.0], [23.3, 4061.0], [23.4, 4084.0], [23.5, 4134.0], [23.6, 4134.0], [23.7, 4147.0], [23.8, 4215.0], [23.9, 4229.0], [24.0, 4240.0], [24.1, 4240.0], [24.2, 4246.0], [24.3, 4256.0], [24.4, 4278.0], [24.5, 4281.0], [24.6, 4281.0], [24.7, 4288.0], [24.8, 4289.0], [24.9, 4292.0], [25.0, 4293.0], [25.1, 4293.0], [25.2, 4303.0], [25.3, 4314.0], [25.4, 4326.0], [25.5, 4329.0], [25.6, 4329.0], [25.7, 4339.0], [25.8, 4341.0], [25.9, 4347.0], [26.0, 4365.0], [26.1, 4365.0], [26.2, 4376.0], [26.3, 4384.0], [26.4, 4389.0], [26.5, 4394.0], [26.6, 4394.0], [26.7, 4401.0], [26.8, 4410.0], [26.9, 4413.0], [27.0, 4427.0], [27.1, 4427.0], [27.2, 4440.0], [27.3, 4465.0], [27.4, 4478.0], [27.5, 4485.0], [27.6, 4485.0], [27.7, 4486.0], [27.8, 4488.0], [27.9, 4489.0], [28.0, 4503.0], [28.1, 4503.0], [28.2, 4510.0], [28.3, 4511.0], [28.4, 4521.0], [28.5, 4569.0], [28.6, 4569.0], [28.7, 4577.0], [28.8, 4584.0], [28.9, 4594.0], [29.0, 4623.0], [29.1, 4623.0], [29.2, 4635.0], [29.3, 4642.0], [29.4, 4647.0], [29.5, 4648.0], [29.6, 4648.0], [29.7, 4651.0], [29.8, 4657.0], [29.9, 4665.0], [30.0, 4673.0], [30.1, 4673.0], [30.2, 4678.0], [30.3, 4711.0], [30.4, 4718.0], [30.5, 4720.0], [30.6, 4720.0], [30.7, 4730.0], [30.8, 4748.0], [30.9, 4759.0], [31.0, 4770.0], [31.1, 4770.0], [31.2, 4773.0], [31.3, 4785.0], [31.4, 4797.0], [31.5, 4821.0], [31.6, 4821.0], [31.7, 4835.0], [31.8, 4851.0], [31.9, 4856.0], [32.0, 4860.0], [32.1, 4860.0], [32.2, 4929.0], [32.3, 4954.0], [32.4, 4957.0], [32.5, 5000.0], [32.6, 5000.0], [32.7, 5003.0], [32.8, 5019.0], [32.9, 5022.0], [33.0, 5029.0], [33.1, 5029.0], [33.2, 5071.0], [33.3, 5086.0], [33.4, 5098.0], [33.5, 5101.0], [33.6, 5101.0], [33.7, 5111.0], [33.8, 5113.0], [33.9, 5119.0], [34.0, 5120.0], [34.1, 5120.0], [34.2, 5129.0], [34.3, 5131.0], [34.4, 5188.0], [34.5, 5202.0], [34.6, 5202.0], [34.7, 5210.0], [34.8, 5239.0], [34.9, 5241.0], [35.0, 5274.0], [35.1, 5274.0], [35.2, 5280.0], [35.3, 5289.0], [35.4, 5291.0], [35.5, 5297.0], [35.6, 5297.0], [35.7, 5301.0], [35.8, 5301.0], [35.9, 5320.0], [36.0, 5331.0], [36.1, 5331.0], [36.2, 5332.0], [36.3, 5364.0], [36.4, 5369.0], [36.5, 5374.0], [36.6, 5374.0], [36.7, 5398.0], [36.8, 5399.0], [36.9, 5413.0], [37.0, 5425.0], [37.1, 5425.0], [37.2, 5451.0], [37.3, 5459.0], [37.4, 5470.0], [37.5, 5472.0], [37.6, 5472.0], [37.7, 5472.0], [37.8, 5480.0], [37.9, 5529.0], [38.0, 5535.0], [38.1, 5535.0], [38.2, 5562.0], [38.3, 5566.0], [38.4, 5570.0], [38.5, 5584.0], [38.6, 5584.0], [38.7, 5585.0], [38.8, 5598.0], [38.9, 5602.0], [39.0, 5613.0], [39.1, 5613.0], [39.2, 5631.0], [39.3, 5636.0], [39.4, 5645.0], [39.5, 5650.0], [39.6, 5650.0], [39.7, 5657.0], [39.8, 5678.0], [39.9, 5681.0], [40.0, 5685.0], [40.1, 5685.0], [40.2, 5691.0], [40.3, 5700.0], [40.4, 5719.0], [40.5, 5725.0], [40.6, 5725.0], [40.7, 5728.0], [40.8, 5742.0], [40.9, 5744.0], [41.0, 5765.0], [41.1, 5765.0], [41.2, 5778.0], [41.3, 5787.0], [41.4, 5790.0], [41.5, 5792.0], [41.6, 5792.0], [41.7, 5807.0], [41.8, 5821.0], [41.9, 5847.0], [42.0, 5850.0], [42.1, 5850.0], [42.2, 5874.0], [42.3, 5890.0], [42.4, 5896.0], [42.5, 5960.0], [42.6, 5960.0], [42.7, 5966.0], [42.8, 5990.0], [42.9, 5991.0], [43.0, 6016.0], [43.1, 6016.0], [43.2, 6052.0], [43.3, 6067.0], [43.4, 6074.0], [43.5, 6084.0], [43.6, 6084.0], [43.7, 6087.0], [43.8, 6115.0], [43.9, 6157.0], [44.0, 6158.0], [44.1, 6158.0], [44.2, 6184.0], [44.3, 6247.0], [44.4, 6251.0], [44.5, 6276.0], [44.6, 6276.0], [44.7, 6286.0], [44.8, 6291.0], [44.9, 6295.0], [45.0, 6327.0], [45.1, 6327.0], [45.2, 6339.0], [45.3, 6349.0], [45.4, 6351.0], [45.5, 6373.0], [45.6, 6373.0], [45.7, 6375.0], [45.8, 6383.0], [45.9, 6390.0], [46.0, 6406.0], [46.1, 6406.0], [46.2, 6459.0], [46.3, 6466.0], [46.4, 6529.0], [46.5, 6529.0], [46.6, 6529.0], [46.7, 6554.0], [46.8, 6568.0], [46.9, 6577.0], [47.0, 6599.0], [47.1, 6599.0], [47.2, 6611.0], [47.3, 6612.0], [47.4, 6620.0], [47.5, 6631.0], [47.6, 6631.0], [47.7, 6641.0], [47.8, 6642.0], [47.9, 6651.0], [48.0, 6651.0], [48.1, 6651.0], [48.2, 6684.0], [48.3, 6690.0], [48.4, 6707.0], [48.5, 6720.0], [48.6, 6720.0], [48.7, 6722.0], [48.8, 6724.0], [48.9, 6738.0], [49.0, 6755.0], [49.1, 6755.0], [49.2, 6758.0], [49.3, 6759.0], [49.4, 6765.0], [49.5, 6766.0], [49.6, 6766.0], [49.7, 6792.0], [49.8, 6796.0], [49.9, 6815.0], [50.0, 6818.0], [50.1, 6818.0], [50.2, 6826.0], [50.3, 6847.0], [50.4, 6856.0], [50.5, 6859.0], [50.6, 6859.0], [50.7, 6863.0], [50.8, 6864.0], [50.9, 6868.0], [51.0, 6870.0], [51.1, 6870.0], [51.2, 6877.0], [51.3, 6933.0], [51.4, 6937.0], [51.5, 6940.0], [51.6, 6940.0], [51.7, 6957.0], [51.8, 6965.0], [51.9, 6995.0], [52.0, 7051.0], [52.1, 7051.0], [52.2, 7099.0], [52.3, 7108.0], [52.4, 7143.0], [52.5, 7148.0], [52.6, 7148.0], [52.7, 7151.0], [52.8, 7177.0], [52.9, 7186.0], [53.0, 7206.0], [53.1, 7206.0], [53.2, 7207.0], [53.3, 7211.0], [53.4, 7212.0], [53.5, 7223.0], [53.6, 7223.0], [53.7, 7226.0], [53.8, 7239.0], [53.9, 7252.0], [54.0, 7283.0], [54.1, 7283.0], [54.2, 7292.0], [54.3, 7292.0], [54.4, 7306.0], [54.5, 7319.0], [54.6, 7319.0], [54.7, 7334.0], [54.8, 7337.0], [54.9, 7342.0], [55.0, 7346.0], [55.1, 7346.0], [55.2, 7370.0], [55.3, 7371.0], [55.4, 7382.0], [55.5, 7383.0], [55.6, 7383.0], [55.7, 7405.0], [55.8, 7411.0], [55.9, 7419.0], [56.0, 7436.0], [56.1, 7436.0], [56.2, 7438.0], [56.3, 7439.0], [56.4, 7461.0], [56.5, 7463.0], [56.6, 7463.0], [56.7, 7483.0], [56.8, 7487.0], [56.9, 7519.0], [57.0, 7521.0], [57.1, 7521.0], [57.2, 7524.0], [57.3, 7526.0], [57.4, 7529.0], [57.5, 7544.0], [57.6, 7544.0], [57.7, 7548.0], [57.8, 7549.0], [57.9, 7551.0], [58.0, 7555.0], [58.1, 7555.0], [58.2, 7568.0], [58.3, 7570.0], [58.4, 7571.0], [58.5, 7576.0], [58.6, 7576.0], [58.7, 7589.0], [58.8, 7598.0], [58.9, 7601.0], [59.0, 7619.0], [59.1, 7619.0], [59.2, 7639.0], [59.3, 7658.0], [59.4, 7658.0], [59.5, 7692.0], [59.6, 7692.0], [59.7, 7700.0], [59.8, 7721.0], [59.9, 7737.0], [60.0, 7745.0], [60.1, 7745.0], [60.2, 7753.0], [60.3, 7759.0], [60.4, 7762.0], [60.5, 7764.0], [60.6, 7764.0], [60.7, 7786.0], [60.8, 7795.0], [60.9, 7827.0], [61.0, 7831.0], [61.1, 7831.0], [61.2, 7842.0], [61.3, 7885.0], [61.4, 7890.0], [61.5, 7913.0], [61.6, 7913.0], [61.7, 7931.0], [61.8, 7936.0], [61.9, 7947.0], [62.0, 7961.0], [62.1, 7961.0], [62.2, 7989.0], [62.3, 8013.0], [62.4, 8015.0], [62.5, 8018.0], [62.6, 8018.0], [62.7, 8022.0], [62.8, 8022.0], [62.9, 8023.0], [63.0, 8035.0], [63.1, 8035.0], [63.2, 8060.0], [63.3, 8067.0], [63.4, 8087.0], [63.5, 8096.0], [63.6, 8096.0], [63.7, 8116.0], [63.8, 8129.0], [63.9, 8135.0], [64.0, 8135.0], [64.1, 8135.0], [64.2, 8137.0], [64.3, 8162.0], [64.4, 8179.0], [64.5, 8238.0], [64.6, 8238.0], [64.7, 8260.0], [64.8, 8285.0], [64.9, 8291.0], [65.0, 8298.0], [65.1, 8298.0], [65.2, 8309.0], [65.3, 8319.0], [65.4, 8323.0], [65.5, 8355.0], [65.6, 8355.0], [65.7, 8364.0], [65.8, 8366.0], [65.9, 8379.0], [66.0, 8412.0], [66.1, 8412.0], [66.2, 8428.0], [66.3, 8445.0], [66.4, 8448.0], [66.5, 8473.0], [66.6, 8473.0], [66.7, 8474.0], [66.8, 8474.0], [66.9, 8492.0], [67.0, 8522.0], [67.1, 8522.0], [67.2, 8551.0], [67.3, 8556.0], [67.4, 8570.0], [67.5, 8573.0], [67.6, 8573.0], [67.7, 8592.0], [67.8, 8598.0], [67.9, 8600.0], [68.0, 8603.0], [68.1, 8603.0], [68.2, 8611.0], [68.3, 8612.0], [68.4, 8627.0], [68.5, 8632.0], [68.6, 8632.0], [68.7, 8648.0], [68.8, 8665.0], [68.9, 8667.0], [69.0, 8677.0], [69.1, 8677.0], [69.2, 8678.0], [69.3, 8680.0], [69.4, 8703.0], [69.5, 8703.0], [69.6, 8703.0], [69.7, 8723.0], [69.8, 8728.0], [69.9, 8737.0], [70.0, 8739.0], [70.1, 8739.0], [70.2, 8756.0], [70.3, 8787.0], [70.4, 8823.0], [70.5, 8823.0], [70.6, 8823.0], [70.7, 8855.0], [70.8, 8861.0], [70.9, 8866.0], [71.0, 8880.0], [71.1, 8880.0], [71.2, 8880.0], [71.3, 8898.0], [71.4, 8900.0], [71.5, 8910.0], [71.6, 8910.0], [71.7, 8912.0], [71.8, 8917.0], [71.9, 8925.0], [72.0, 8954.0], [72.1, 8954.0], [72.2, 8973.0], [72.3, 8975.0], [72.4, 8978.0], [72.5, 8992.0], [72.6, 8992.0], [72.7, 9015.0], [72.8, 9018.0], [72.9, 9022.0], [73.0, 9039.0], [73.1, 9039.0], [73.2, 9091.0], [73.3, 9096.0], [73.4, 9119.0], [73.5, 9134.0], [73.6, 9134.0], [73.7, 9153.0], [73.8, 9169.0], [73.9, 9172.0], [74.0, 9186.0], [74.1, 9186.0], [74.2, 9195.0], [74.3, 9199.0], [74.4, 9206.0], [74.5, 9213.0], [74.6, 9213.0], [74.7, 9247.0], [74.8, 9280.0], [74.9, 9283.0], [75.0, 9286.0], [75.1, 9286.0], [75.2, 9288.0], [75.3, 9289.0], [75.4, 9290.0], [75.5, 9294.0], [75.6, 9294.0], [75.7, 9307.0], [75.8, 9313.0], [75.9, 9317.0], [76.0, 9349.0], [76.1, 9349.0], [76.2, 9358.0], [76.3, 9359.0], [76.4, 9364.0], [76.5, 9366.0], [76.6, 9366.0], [76.7, 9372.0], [76.8, 9378.0], [76.9, 9388.0], [77.0, 9417.0], [77.1, 9417.0], [77.2, 9424.0], [77.3, 9425.0], [77.4, 9432.0], [77.5, 9440.0], [77.6, 9440.0], [77.7, 9444.0], [77.8, 9453.0], [77.9, 9458.0], [78.0, 9458.0], [78.1, 9458.0], [78.2, 9481.0], [78.3, 9490.0], [78.4, 9494.0], [78.5, 9497.0], [78.6, 9497.0], [78.7, 9512.0], [78.8, 9524.0], [78.9, 9525.0], [79.0, 9541.0], [79.1, 9541.0], [79.2, 9542.0], [79.3, 9549.0], [79.4, 9553.0], [79.5, 9558.0], [79.6, 9558.0], [79.7, 9572.0], [79.8, 9579.0], [79.9, 9589.0], [80.0, 9608.0], [80.1, 9608.0], [80.2, 9620.0], [80.3, 9622.0], [80.4, 9625.0], [80.5, 9630.0], [80.6, 9630.0], [80.7, 9670.0], [80.8, 9688.0], [80.9, 9690.0], [81.0, 9704.0], [81.1, 9704.0], [81.2, 9727.0], [81.3, 9738.0], [81.4, 9741.0], [81.5, 9746.0], [81.6, 9746.0], [81.7, 9760.0], [81.8, 9765.0], [81.9, 9774.0], [82.0, 9775.0], [82.1, 9775.0], [82.2, 9786.0], [82.3, 9796.0], [82.4, 9809.0], [82.5, 9816.0], [82.6, 9816.0], [82.7, 9820.0], [82.8, 9831.0], [82.9, 9856.0], [83.0, 9857.0], [83.1, 9857.0], [83.2, 9863.0], [83.3, 9905.0], [83.4, 9905.0], [83.5, 9915.0], [83.6, 9915.0], [83.7, 9948.0], [83.8, 9955.0], [83.9, 9965.0], [84.0, 9978.0], [84.1, 9978.0], [84.2, 9981.0], [84.3, 9989.0], [84.4, 10012.0], [84.5, 10013.0], [84.6, 10013.0], [84.7, 10017.0], [84.8, 10039.0], [84.9, 10064.0], [85.0, 10066.0], [85.1, 10066.0], [85.2, 10076.0], [85.3, 10092.0], [85.4, 10128.0], [85.5, 10144.0], [85.6, 10144.0], [85.7, 10146.0], [85.8, 10150.0], [85.9, 10162.0], [86.0, 10201.0], [86.1, 10201.0], [86.2, 10227.0], [86.3, 10278.0], [86.4, 10290.0], [86.5, 10299.0], [86.6, 10299.0], [86.7, 10300.0], [86.8, 10317.0], [86.9, 10328.0], [87.0, 10329.0], [87.1, 10329.0], [87.2, 10340.0], [87.3, 10340.0], [87.4, 10355.0], [87.5, 10356.0], [87.6, 10356.0], [87.7, 10362.0], [87.8, 10365.0], [87.9, 10410.0], [88.0, 10414.0], [88.1, 10414.0], [88.2, 10415.0], [88.3, 10419.0], [88.4, 10432.0], [88.5, 10434.0], [88.6, 10434.0], [88.7, 10440.0], [88.8, 10444.0], [88.9, 10448.0], [89.0, 10460.0], [89.1, 10460.0], [89.2, 10464.0], [89.3, 10481.0], [89.4, 10488.0], [89.5, 10503.0], [89.6, 10503.0], [89.7, 10511.0], [89.8, 10511.0], [89.9, 10525.0], [90.0, 10530.0], [90.1, 10530.0], [90.2, 10543.0], [90.3, 10553.0], [90.4, 10566.0], [90.5, 10570.0], [90.6, 10570.0], [90.7, 10573.0], [90.8, 10586.0], [90.9, 10616.0], [91.0, 10625.0], [91.1, 10625.0], [91.2, 10631.0], [91.3, 10642.0], [91.4, 10649.0], [91.5, 10652.0], [91.6, 10652.0], [91.7, 10653.0], [91.8, 10665.0], [91.9, 10686.0], [92.0, 10693.0], [92.1, 10693.0], [92.2, 10708.0], [92.3, 10729.0], [92.4, 10747.0], [92.5, 10756.0], [92.6, 10756.0], [92.7, 10759.0], [92.8, 10775.0], [92.9, 10776.0], [93.0, 10778.0], [93.1, 10778.0], [93.2, 10789.0], [93.3, 10802.0], [93.4, 10817.0], [93.5, 10866.0], [93.6, 10866.0], [93.7, 10886.0], [93.8, 10887.0], [93.9, 10888.0], [94.0, 10910.0], [94.1, 10910.0], [94.2, 10931.0], [94.3, 10954.0], [94.4, 10986.0], [94.5, 11002.0], [94.6, 11002.0], [94.7, 11003.0], [94.8, 11023.0], [94.9, 11032.0], [95.0, 11047.0], [95.1, 11047.0], [95.2, 11109.0], [95.3, 11133.0], [95.4, 11147.0], [95.5, 11163.0], [95.6, 11163.0], [95.7, 11168.0], [95.8, 11207.0], [95.9, 11230.0], [96.0, 11231.0], [96.1, 11231.0], [96.2, 11255.0], [96.3, 11309.0], [96.4, 11316.0], [96.5, 11334.0], [96.6, 11334.0], [96.7, 11341.0], [96.8, 11384.0], [96.9, 11389.0], [97.0, 11417.0], [97.1, 11417.0], [97.2, 11464.0], [97.3, 11474.0], [97.4, 11578.0], [97.5, 11579.0], [97.6, 11579.0], [97.7, 11640.0], [97.8, 11686.0], [97.9, 11686.0], [98.0, 11693.0], [98.1, 11693.0], [98.2, 11720.0], [98.3, 11875.0], [98.4, 12037.0], [98.5, 12071.0], [98.6, 12071.0], [98.7, 12304.0], [98.8, 12376.0], [98.9, 12460.0], [99.0, 12563.0], [99.1, 12563.0], [99.2, 12628.0], [99.3, 12634.0], [99.4, 12817.0], [99.5, 13002.0], [99.6, 13002.0], [99.7, 13202.0], [99.8, 14241.0], [99.9, 14274.0]], "isOverall": false, "label": "Seconds", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 1100.0, "maxY": 16.0, "series": [{"data": [[1100.0, 1.0], [1200.0, 3.0], [1300.0, 5.0], [1400.0, 4.0], [1500.0, 4.0], [1600.0, 6.0], [1700.0, 4.0], [1800.0, 2.0], [2000.0, 3.0], [2100.0, 5.0], [2300.0, 10.0], [2200.0, 4.0], [2400.0, 6.0], [2500.0, 6.0], [2600.0, 11.0], [2700.0, 14.0], [2800.0, 8.0], [2900.0, 7.0], [3000.0, 7.0], [3100.0, 13.0], [3200.0, 8.0], [3300.0, 5.0], [3400.0, 11.0], [3500.0, 5.0], [3600.0, 11.0], [3700.0, 4.0], [3800.0, 8.0], [3900.0, 7.0], [4000.0, 6.0], [4100.0, 2.0], [4300.0, 12.0], [4200.0, 11.0], [4400.0, 11.0], [4500.0, 8.0], [4600.0, 10.0], [4700.0, 10.0], [4800.0, 5.0], [5100.0, 8.0], [5000.0, 8.0], [4900.0, 3.0], [5300.0, 10.0], [5200.0, 9.0], [5500.0, 8.0], [5400.0, 8.0], [5600.0, 11.0], [5700.0, 11.0], [5800.0, 7.0], [6100.0, 4.0], [6000.0, 6.0], [5900.0, 4.0], [6300.0, 8.0], [6200.0, 6.0], [6600.0, 10.0], [6500.0, 6.0], [6400.0, 3.0], [6700.0, 12.0], [6800.0, 11.0], [6900.0, 6.0], [7100.0, 6.0], [7000.0, 2.0], [7300.0, 10.0], [7200.0, 11.0], [7400.0, 10.0], [7600.0, 6.0], [7500.0, 16.0], [7900.0, 6.0], [7700.0, 10.0], [7800.0, 5.0], [8100.0, 7.0], [8000.0, 11.0], [8300.0, 7.0], [8700.0, 8.0], [8400.0, 8.0], [8200.0, 5.0], [8600.0, 12.0], [8500.0, 7.0], [8800.0, 8.0], [8900.0, 10.0], [9200.0, 10.0], [9100.0, 8.0], [9000.0, 6.0], [9700.0, 11.0], [9300.0, 11.0], [9500.0, 11.0], [9600.0, 8.0], [9400.0, 13.0], [10000.0, 8.0], [9900.0, 9.0], [10100.0, 5.0], [10200.0, 5.0], [9800.0, 7.0], [10400.0, 13.0], [10600.0, 10.0], [10300.0, 10.0], [10700.0, 9.0], [10500.0, 11.0], [10900.0, 4.0], [11200.0, 4.0], [10800.0, 6.0], [11100.0, 5.0], [11000.0, 5.0], [11400.0, 3.0], [11600.0, 4.0], [11300.0, 6.0], [11700.0, 1.0], [11500.0, 2.0], [11800.0, 1.0], [12000.0, 2.0], [12600.0, 2.0], [12500.0, 1.0], [12300.0, 2.0], [12400.0, 1.0], [13200.0, 1.0], [12800.0, 1.0], [13000.0, 1.0], [14200.0, 2.0]], "isOverall": false, "label": "Seconds", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 14200.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 2.0, "minX": 1.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 787.0, "series": [{"data": [], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 11.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 787.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 2.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 8.666666666666664, "minX": 1.74283506E12, "maxY": 78.75555555555557, "series": [{"data": [[1.74283512E12, 72.15756630265204], [1.74283518E12, 8.666666666666664], [1.74283506E12, 78.75555555555557]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.74283518E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 20700000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 1751.0, "minX": 1.0, "maxY": 11474.0, "series": [{"data": [[2.0, 8616.5], [3.0, 7663.0], [4.0, 10299.0], [5.0, 11474.0], [6.0, 9252.0], [7.0, 11049.0], [8.0, 10310.5], [9.0, 8379.0], [10.0, 9091.0], [11.0, 9010.5], [12.0, 6792.0], [13.0, 3275.0], [14.0, 9199.0], [15.0, 8598.0], [16.0, 10778.0], [17.0, 5188.0], [18.0, 6940.0], [19.0, 6067.0], [21.0, 9942.333333333334], [22.0, 10036.333333333334], [23.0, 10434.0], [24.0, 3279.0], [25.0, 4642.0], [26.0, 1751.0], [27.0, 3883.0], [28.0, 7431.75], [29.0, 9045.0], [30.0, 5886.5], [31.0, 8657.5], [33.0, 8481.5], [32.0, 7463.0], [35.0, 8450.6], [34.0, 9690.0], [37.0, 6251.0], [36.0, 4045.3333333333335], [39.0, 7553.5], [40.0, 6513.666666666667], [41.0, 7539.5], [43.0, 5070.75], [42.0, 7999.333333333333], [45.0, 7030.666666666667], [44.0, 6261.0], [47.0, 8474.0], [46.0, 5584.0], [49.0, 8853.666666666666], [48.0, 7282.0], [51.0, 4721.0], [50.0, 11334.0], [53.0, 4718.0], [52.0, 8135.5], [55.0, 6507.4], [54.0, 9378.0], [56.0, 3857.5], [57.0, 7140.421052631578], [59.0, 4641.0], [58.0, 10693.0], [61.0, 6062.5], [60.0, 7553.5], [63.0, 7662.571428571428], [62.0, 7073.888888888889], [67.0, 7767.125], [66.0, 9627.0], [65.0, 4781.666666666667], [64.0, 6790.5], [71.0, 5443.0], [70.0, 6626.105263157895], [69.0, 3397.0], [68.0, 6363.111111111111], [72.0, 3794.666666666667], [75.0, 6140.1], [74.0, 5461.666666666667], [73.0, 8055.714285714284], [76.0, 4528.250000000001], [79.0, 6106.791666666667], [78.0, 6856.25], [77.0, 6596.5], [80.0, 6708.034557235423], [1.0, 10144.0]], "isOverall": false, "label": "Seconds", "isController": false}, {"data": [[71.36624999999998, 6721.701249999995]], "isOverall": false, "label": "Seconds-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 80.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 167.68333333333334, "minX": 1.74283506E12, "maxY": 10021.516666666666, "series": [{"data": [[1.74283512E12, 10021.516666666666], [1.74283518E12, 375.68333333333334], [1.74283506E12, 2101.883333333333]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.74283512E12, 4477.216666666666], [1.74283518E12, 167.68333333333334], [1.74283506E12, 942.9166666666666]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.74283518E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 20700000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 6557.022222222224, "minX": 1.74283506E12, "maxY": 8831.666666666668, "series": [{"data": [[1.74283512E12, 6677.383775351012], [1.74283518E12, 8831.666666666668], [1.74283506E12, 6557.022222222224]], "isOverall": false, "label": "Seconds", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.74283518E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 20700000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 6556.977777777779, "minX": 1.74283506E12, "maxY": 8831.666666666668, "series": [{"data": [[1.74283512E12, 6677.3588143525685], [1.74283518E12, 8831.666666666668], [1.74283506E12, 6556.977777777779]], "isOverall": false, "label": "Seconds", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.74283518E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 20700000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 48.33541341653666, "minX": 1.74283506E12, "maxY": 505.0666666666665, "series": [{"data": [[1.74283512E12, 48.33541341653666], [1.74283518E12, 251.1666666666667], [1.74283506E12, 505.0666666666665]], "isOverall": false, "label": "Seconds", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.74283518E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 20700000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 1284.0, "minX": 1.74283506E12, "maxY": 14274.0, "series": [{"data": [[1.74283512E12, 14274.0], [1.74283518E12, 13002.0], [1.74283506E12, 14241.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.74283512E12, 10501.5], [1.74283518E12, 11318.5], [1.74283506E12, 10786.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.74283512E12, 12346.480000000003], [1.74283518E12, 13002.0], [1.74283506E12, 13877.350000000006]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.74283512E12, 10908.899999999998], [1.74283518E12, 12620.0], [1.74283506E12, 11508.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.74283512E12, 1284.0], [1.74283518E12, 3275.0], [1.74283506E12, 1388.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.74283512E12, 6762.0], [1.74283518E12, 9093.5], [1.74283506E12, 6604.5]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.74283518E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 20700000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 1156.0, "minX": 1.0, "maxY": 9620.0, "series": [{"data": [[2.0, 8060.0], [8.0, 5974.5], [9.0, 7177.0], [10.0, 6350.0], [11.0, 5746.5], [12.0, 6853.0], [13.0, 6766.0], [14.0, 6859.5], [15.0, 8737.0], [4.0, 3802.5], [16.0, 6702.0], [1.0, 9620.0], [17.0, 8667.5], [20.0, 6493.0], [5.0, 7519.0], [6.0, 7390.5], [7.0, 7551.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[2.0, 1156.0], [15.0, 1388.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 20.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 1156.0, "minX": 1.0, "maxY": 9620.0, "series": [{"data": [[2.0, 8060.0], [8.0, 5974.5], [9.0, 7177.0], [10.0, 6350.0], [11.0, 5746.5], [12.0, 6853.0], [13.0, 6766.0], [14.0, 6859.5], [15.0, 8737.0], [4.0, 3802.5], [16.0, 6702.0], [1.0, 9620.0], [17.0, 8667.5], [20.0, 6493.0], [5.0, 7519.0], [6.0, 7390.5], [7.0, 7551.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[2.0, 1156.0], [15.0, 1388.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 20.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.1, "minX": 1.74283506E12, "maxY": 9.65, "series": [{"data": [[1.74283512E12, 9.65], [1.74283518E12, 0.1], [1.74283506E12, 3.5833333333333335]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.74283518E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 20700000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.74283506E12, "maxY": 10.666666666666666, "series": [{"data": [[1.74283512E12, 10.666666666666666], [1.74283518E12, 0.4], [1.74283506E12, 2.2333333333333334]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.74283512E12, 0.016666666666666666], [1.74283506E12, 0.016666666666666666]], "isOverall": false, "label": "502", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.74283518E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 20700000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.74283506E12, "maxY": 10.666666666666666, "series": [{"data": [[1.74283512E12, 10.666666666666666], [1.74283518E12, 0.4], [1.74283506E12, 2.2333333333333334]], "isOverall": false, "label": "Seconds-success", "isController": false}, {"data": [[1.74283512E12, 0.016666666666666666], [1.74283506E12, 0.016666666666666666]], "isOverall": false, "label": "Seconds-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.74283518E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 20700000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.74283506E12, "maxY": 10.666666666666666, "series": [{"data": [[1.74283512E12, 10.666666666666666], [1.74283518E12, 0.4], [1.74283506E12, 2.2333333333333334]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.74283512E12, 0.016666666666666666], [1.74283506E12, 0.016666666666666666]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.74283518E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 20700000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

